function updateTextField() {
  const inputText = document.getElementById("inputText").value;
  document.getElementById("outputText").value = inputText;
}
